import {it,expect} from 'vitest';
import {env} from 'cloudflare:workers';
import {runInDurableObject,evictDurableObject} from 'cloudflare:test';
import {currentRestoreFixture,captureCurrentFixture,withCurrentRecoveryWorkspace,targetArtifactBucket,type CurrentRestoreFixture} from './current-restore-fixture';
import {TABLE_REGISTRY} from '../../src/recovery/table-registry';
import {canonicalBytes,digestBytes,decodeCurrentChunk} from '../../src/recovery/encoding';
import {validateManifestShape,verifyRecord} from '../../src/recovery/manifest';
import {validateRecoveryReceipt} from '../../src/recovery/generated/recovery-validators.js';
import {beginRestore,writeRestoreChunk,advanceVerify} from '../../src/recovery/restore';
import {fixtureIntegrity,recoveryContext} from '../helpers/recovery-fixture';
import {artifactBucket} from '../helpers/artifacts';
import {human,owned} from '../helpers/settings';
import {canonicalJson,sha256} from '../../src/config/bootstrap';
import {csrfToken} from '../../src/auth/csrf';
import {withTransaction} from '../../src/storage/transaction';
import {storeObservationSlot,assertObservationGraph,type ObservationSlotRow,type ObservationMetadata} from '../../src/observations/repository';
import type {SessionRecord} from '../../src/auth/authorize';
const provenance={commit:'ad0f1b39a1431aa29726b5fc3b77c1a13e08118b',tree:'6c1e3df81b9b2ff72bb531438085a7d860b3182f',public_commit:'bfe621c3dab2a0cab672feadd1916ec154188db9',public_repository:'trungtaottn/cf-agent-hub',public_pr:141,synthetic:true,producer:'test/recovery/schema18-producer.test.ts',runtime:'actual local workerd via @cloudflare/vitest-plugin; original production source untouched'};
async function objects(bucket:R2Bucket){
 const result=[];let cursor:string|undefined;
 do{const page=await bucket.list({cursor});for(const object of page.objects){const body=await bucket.get(object.key);if(!body)throw Error('Missing object');result.push({key:object.key,bytes:Array.from(new Uint8Array(await body.arrayBuffer()))});}cursor=page.truncated?page.cursor:undefined;}while(cursor);
 return result;
}
async function snapshot(f:CurrentRestoreFixture,lane:'source'|'target'){
 const sql=await withCurrentRecoveryWorkspace(f,lane,w=>({tables:Object.fromEntries(TABLE_REGISTRY.map(t=>[t.name,w.storage.sql.exec('SELECT * FROM "'+t.name+'" ORDER BY '+t.primaryKey.map(c=>'"'+c+'"').join(',')).toArray()])),sequence:w.storage.sql.exec('SELECT name,seq FROM sqlite_sequence ORDER BY name').toArray(),release:w.release}));
 return {...sql,objects:await objects(env.RECOVERY_BUCKET),sourceArtifactObjects:await objects(artifactBucket()),targetArtifactObjects:await objects(targetArtifactBucket())};
}
async function emit(name:string,data:unknown){const sink=(env as unknown as {SCHEMA18_FIXTURE_SINK:Fetcher}).SCHEMA18_FIXTURE_SINK;const response=await sink.fetch('https://fixture.example.invalid/'+name,{method:'POST',body:JSON.stringify(data)});expect(response.status).toBe(204);}
it('captures original schema18 signed recovery bytes plus captured/importing/completed lifecycle SQL and R2',async()=>{
 const f=await currentRestoreFixture('genuine18_'+crypto.randomUUID().replaceAll('-',''),{rich:true});
 // Synthetic repository-seeded diagnostic graph; not evidence of HTTP ingestion.
 const session='obs_'+crypto.randomUUID().replaceAll('-','')+'a'.repeat(16);
 await runInDurableObject(f.source,(_instance,{storage})=>withTransaction(storage,tx=>{
  const run=tx.one<any>("SELECT * FROM runs WHERE id='run_b'")!;
  const metadata:ObservationMetadata={repository_id:'repository_example',checkout_slot_id:'checkout_a',coverage:{configured_events:['write-observed'],completeness:'unknown',reported_loss:false},latest_batch_receipt:{kind:'batch_receipt',session_id:session,first_sequence:1,last_sequence:1,record_count:1,accepted_at:'2026-10-31T00:00:00.000Z',request_fingerprint:'b'.repeat(64)},latest_replacement_receipt:null,retained_range:{first_sequence:1,last_sequence:1},truncated:false};
  const row:ObservationSlotRow={slot:0,workspace_id:'ws_example',task_id:run.task_id,project_id:'historical_project',run_id:run.id,agent_id:run.agent_id,runtime_instance_id:run.runtime_instance_id,credential_id:run.credential_id,authority_epoch:run.authority_epoch,maintenance_generation:0,mapping_digest:'c'.repeat(64),session_id:session,session_epoch:1,high_water:1,created_at:1,metadata_json:'',metadata_bytes:0};
  storeObservationSlot(tx,row,metadata);
  const record=canonicalJson({observed_at:'2026-10-31T00:00:00.000Z',relative_path:'src/example.ts',activity:'write-observed',source_oid:null});
  tx.exec('INSERT INTO observation_records(session_id,sequence,ingest_order,received_at,record_json,record_bytes) VALUES (?,1,1,1,?,?)',[session,record,new TextEncoder().encode(record).length]);
  assertObservationGraph(tx);
 }));

 // Actual browser prepare endpoint makes an unconsumed schema18 reservation, not handwritten SQL.
 const admission=await runInDurableObject(f.source,async(object,{storage})=>{
  const identity=human(storage);if(identity.kind!=='human')throw Error('Expected human');
  const cookie='D'.repeat(43);await sha256(cookie).then(digest=>storage.sql.exec('UPDATE sessions SET token_digest=? WHERE id=?',digest,identity.sessionId));
  const workspace={...owned(storage,f.sourceName),secrets:env as unknown as Record<string,unknown>};
  const csrf=await csrfToken(workspace,withTransaction(storage,tx=>tx.one<SessionRecord>('SELECT * FROM sessions WHERE id=?',[identity.sessionId])!));
  const response=await object.fetch(new Request('https://hub.example.invalid/v2/workspaces/ws_example/tasks:prepare',{method:'POST',headers:{'content-type':'application/json',origin:'https://hub.example.invalid',cookie:'cfhub_session='+cookie,'x-csrf-token':csrf,'idempotency-key':'pending_schema18_future'},body:JSON.stringify({title:'Synthetic pending schema18 future',description:'Unconsumed original browser preparation'})}));
  expect(response.status).toBe(200);const data=(await response.json() as {data:{admission_id:string}}).data;expect(storage.sql.exec('SELECT id FROM creation_admissions WHERE id=?',data.admission_id).one().id).toBe(data.admission_id);return data;
 });
 const original=await captureCurrentFixture(f,{evict:true});
 validateManifestShape(original.manifest);await verifyRecord(original.manifest,fixtureIntegrity);await verifyRecord(f.ledger,fixtureIntegrity);expect(validateRecoveryReceipt(original.progress.receipt)).toBe(true);
 const chunks=[];const stream=new (crypto as Crypto&{DigestStream:typeof DigestStream}).DigestStream('SHA-256'),writer=stream.getWriter();
 for(const chunk of original.chunks){const bytes=new Uint8Array(chunk.bytes);expect(await digestBytes(bytes)).toBe(chunk.metadata.sha256);const decoded=decodeCurrentChunk(bytes);expect(decoded.schema_version).toBe(18);await writer.write(bytes);chunks.push({...chunk,bytes:Array.from(bytes)});}await writer.close();expect(Array.from(new Uint8Array(await stream.digest),b=>b.toString(16).padStart(2,'0')).join('')).toBe(original.manifest.database.sha256);
 const artifacts=[];for(const entry of original.manifest.artifacts){const object=await env.RECOVERY_BUCKET.get(entry.recovery_object_key);expect(object).not.toBeNull();const bytes=new Uint8Array(await object!.arrayBuffer());expect(bytes.length).toBe(entry.byte_size);expect(await digestBytes(bytes)).toBe(entry.sha256);artifacts.push({entry,bytes:Array.from(bytes)});}
 const capture={...original,chunks,artifacts};
 const {source,target,...fixture}=f;
 const sourceSnapshot=await snapshot(f,'source');
 expect(sourceSnapshot.tables.observation_slots).toHaveLength(1);expect(sourceSnapshot.tables.observation_records).toHaveLength(1);expect(sourceSnapshot.tables.creation_admissions).toHaveLength(1);expect(sourceSnapshot.tables.messages.length).toBeGreaterThan(0);expect(sourceSnapshot.tables.tasks.length).toBeGreaterThan(0);expect(artifacts.length).toBeGreaterThan(0);
 await emit('genuine-schema18-bundle.json',{provenance,fixture,capture});
 await emit('genuine-schema18-snapshot-bundle.json',{provenance,fixture,snapshot:sourceSnapshot,capture});
 let progress=await withCurrentRecoveryWorkspace(f,'target',async w=>beginRestore(w,await recoveryContext(w,'restore',{manifest:original.manifest,ledger:f.ledger},f.captureId,{anchor:f.anchor,operationId:'begin_current_restore'}),original.manifest,f.ledger));
 const boundary=Math.ceil(original.chunks.length/2);let inflight:unknown;
 for(const [index,chunk] of original.chunks.entries()){
  const metadata={index:chunk.metadata.index,sha256:chunk.metadata.sha256,byte_size:chunk.metadata.byte_size};progress=await withCurrentRecoveryWorkspace(f,'target',async w=>writeRestoreChunk(w,await recoveryContext(w,'write-chunk',metadata,f.captureId,{anchor:f.anchor,operationId:'write_'+metadata.index}),metadata,new Uint8Array(chunk.bytes)));await evictDurableObject(f.target);
  if(index+1===boundary){expect(progress.state).toBe('running');inflight={progress:structuredClone(progress),snapshot:await snapshot(f,'target'),nextChunkIndex:index+1,nextVerifyStep:0};}
 }
 let nextVerifyStep=0;for(;nextVerifyStep<500&&progress.state==='running';nextVerifyStep++){
  progress=await withCurrentRecoveryWorkspace(f,'target',async w=>advanceVerify(w,await recoveryContext(w,'verify',{manifest:original.manifest},f.captureId,{anchor:f.anchor,operationId:'verify_'+nextVerifyStep}),original.manifest));await evictDurableObject(f.target);
 }
 expect(progress.state).toBe('complete');expect(validateRecoveryReceipt(progress.receipt)).toBe(true);const completed={progress,snapshot:await snapshot(f,'target'),nextChunkIndex:original.chunks.length,nextVerifyStep};
 expect(completed.snapshot.tables.observation_slots).toEqual([]);expect(completed.snapshot.tables.observation_records).toEqual([]);expect(completed.snapshot.tables.creation_admissions).toEqual([]);expect(completed.snapshot.tables.maintenance_state[0].state).toBe('restored');expect(completed.snapshot.tables.schema_migrations.length).toBe(18);
 expect(await digestBytes(canonicalBytes(original.manifest))).toBe(await digestBytes(canonicalBytes(capture.manifest)));
 await emit('genuine-schema18-restore-lifecycle-bundle.json',{provenance,fixture,capture,inflight,completed});
 console.log('SCHEMA18_CAPTURE_READY',JSON.stringify({schema:18,tableCounts:original.manifest.database.table_counts,chunks:chunks.length,artifacts:artifacts.length,pendingAdmission:admission.admission_id,partialImportNextChunk:boundary,completeRestoreState:progress.state,manifestSha256:await digestBytes(canonicalBytes(original.manifest))}));
},180000);
