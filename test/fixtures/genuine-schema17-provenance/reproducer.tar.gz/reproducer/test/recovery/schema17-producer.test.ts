import {it,expect} from 'vitest';
import {env} from 'cloudflare:workers';
import {runInDurableObject,evictDurableObject} from 'cloudflare:test';
import {currentRestoreFixture,captureCurrentFixture,withCurrentRecoveryWorkspace,targetArtifactBucket,type CurrentRestoreFixture} from './current-restore-fixture';
import {TABLE_REGISTRY} from '../../src/recovery/table-registry';
import {canonicalBytes,digestBytes,decodeCurrentChunk} from '../../src/recovery/encoding';
import {validateManifestShape,verifyRecord} from '../../src/recovery/manifest';
import {validateRecoveryReceipt} from '../../src/recovery/generated/recovery-validators.js';
import {beginRestore,writeRestoreChunk,advanceVerify} from '../../src/recovery/restore';
import {fixtureIntegrity,recoveryContext} from '../helpers/recovery-fixture';
import {artifactBucket} from '../helpers/artifacts';
import {human,owned} from '../helpers/settings';
import {sha256} from '../../src/config/bootstrap';
import {csrfToken} from '../../src/auth/csrf';
import {withTransaction} from '../../src/storage/transaction';
import type {SessionRecord} from '../../src/auth/authorize';
const provenance={commit:'e427ab862183527516daba5dd53e78d1222a8dce',tree:'3c6eb659c6ad6d30ddd30bc6b22500d819a6c73a',public_commit:'77ee610c13a61077dc866a66556eafdfcb1d2553',public_repository:'trungtaottn/cf-agent-hub',public_pr:138,synthetic:true,producer:'test/recovery/schema17-producer.test.ts',runtime:'actual local workerd via @cloudflare/vitest-plugin; original production source untouched'};
async function objects(bucket:R2Bucket){
 const result=[];let cursor:string|undefined;
 do{const page=await bucket.list({cursor});for(const object of page.objects){const body=await bucket.get(object.key);if(!body)throw Error('Missing object');result.push({key:object.key,bytes:Array.from(new Uint8Array(await body.arrayBuffer()))});}cursor=page.truncated?page.cursor:undefined;}while(cursor);
 return result;
}
async function snapshot(f:CurrentRestoreFixture,lane:'source'|'target'){
 const sql=await withCurrentRecoveryWorkspace(f,lane,w=>({tables:Object.fromEntries(TABLE_REGISTRY.map(t=>[t.name,w.storage.sql.exec('SELECT * FROM "'+t.name+'" ORDER BY '+t.primaryKey.map(c=>'"'+c+'"').join(',')).toArray()])),sequence:w.storage.sql.exec('SELECT name,seq FROM sqlite_sequence ORDER BY name').toArray(),release:w.release}));
 return {...sql,objects:await objects(env.RECOVERY_BUCKET),sourceArtifactObjects:await objects(artifactBucket()),targetArtifactObjects:await objects(targetArtifactBucket())};
}
async function emit(name:string,data:unknown){const sink=(env as unknown as {SCHEMA17_FIXTURE_SINK:Fetcher}).SCHEMA17_FIXTURE_SINK;const response=await sink.fetch('https://fixture.example.invalid/'+name,{method:'POST',body:JSON.stringify(data)});expect(response.status).toBe(204);}
it('captures original schema17 signed recovery bytes plus captured/importing/completed lifecycle SQL and R2',async()=>{
 const f=await currentRestoreFixture('genuine17_oldbinary',{rich:true});
 // Actual browser prepare endpoint makes an unconsumed schema17 reservation, not handwritten SQL.
 const admission=await runInDurableObject(f.source,async(object,{storage})=>{
  const identity=human(storage);if(identity.kind!=='human')throw Error('Expected human');
  const cookie='D'.repeat(43);await sha256(cookie).then(digest=>storage.sql.exec('UPDATE sessions SET token_digest=? WHERE id=?',digest,identity.sessionId));
  const workspace={...owned(storage,f.sourceName),secrets:env as unknown as Record<string,unknown>};
  const csrf=await csrfToken(workspace,withTransaction(storage,tx=>tx.one<SessionRecord>('SELECT * FROM sessions WHERE id=?',[identity.sessionId])!));
  const response=await object.fetch(new Request('https://hub.example.invalid/v2/workspaces/ws_example/tasks:prepare',{method:'POST',headers:{'content-type':'application/json',origin:'https://hub.example.invalid',cookie:'cfhub_session='+cookie,'x-csrf-token':csrf,'idempotency-key':'pending_schema17_future'},body:JSON.stringify({title:'Synthetic pending schema17 future',description:'Unconsumed original browser preparation'})}));
  expect(response.status).toBe(200);const data=(await response.json() as {data:{admission_id:string}}).data;expect(storage.sql.exec('SELECT id FROM creation_admissions WHERE id=?',data.admission_id).one().id).toBe(data.admission_id);return data;
 });
 const original=await captureCurrentFixture(f,{evict:true});
 validateManifestShape(original.manifest);await verifyRecord(original.manifest,fixtureIntegrity);await verifyRecord(f.ledger,fixtureIntegrity);expect(validateRecoveryReceipt(original.progress.receipt)).toBe(true);
 const chunks=[];const stream=new (crypto as Crypto&{DigestStream:typeof DigestStream}).DigestStream('SHA-256'),writer=stream.getWriter();
 for(const chunk of original.chunks){const bytes=new Uint8Array(chunk.bytes);expect(await digestBytes(bytes)).toBe(chunk.metadata.sha256);const decoded=decodeCurrentChunk(bytes);expect(decoded.schema_version).toBe(17);await writer.write(bytes);chunks.push({...chunk,bytes:Array.from(bytes)});}await writer.close();expect(Array.from(new Uint8Array(await stream.digest),b=>b.toString(16).padStart(2,'0')).join('')).toBe(original.manifest.database.sha256);
 const artifacts=[];for(const entry of original.manifest.artifacts){const object=await env.RECOVERY_BUCKET.get(entry.recovery_object_key);expect(object).not.toBeNull();const bytes=new Uint8Array(await object!.arrayBuffer());expect(bytes.length).toBe(entry.byte_size);expect(await digestBytes(bytes)).toBe(entry.sha256);artifacts.push({entry,bytes:Array.from(bytes)});}
 const capture={...original,chunks,artifacts};
 const {source,target,...fixture}=f;
 const sourceSnapshot=await snapshot(f,'source');
 expect(sourceSnapshot.tables.creation_admissions).toHaveLength(1);expect(sourceSnapshot.tables.messages.length).toBeGreaterThan(0);expect(sourceSnapshot.tables.tasks.length).toBeGreaterThan(0);expect(artifacts.length).toBeGreaterThan(0);
 await emit('genuine-schema17-bundle.json',{provenance,fixture,capture});
 await emit('genuine-schema17-snapshot-bundle.json',{provenance,fixture,snapshot:sourceSnapshot,capture});
 let progress=await withCurrentRecoveryWorkspace(f,'target',async w=>beginRestore(w,await recoveryContext(w,'restore',{manifest:original.manifest,ledger:f.ledger},f.captureId,{anchor:f.anchor,operationId:'begin_current_restore'}),original.manifest,f.ledger));
 const boundary=Math.ceil(original.chunks.length/2);let inflight:unknown;
 for(const [index,chunk] of original.chunks.entries()){
  const metadata={index:chunk.metadata.index,sha256:chunk.metadata.sha256,byte_size:chunk.metadata.byte_size};progress=await withCurrentRecoveryWorkspace(f,'target',async w=>writeRestoreChunk(w,await recoveryContext(w,'write-chunk',metadata,f.captureId,{anchor:f.anchor,operationId:'write_'+metadata.index}),metadata,new Uint8Array(chunk.bytes)));await evictDurableObject(f.target);
  if(index+1===boundary){expect(progress.state).toBe('running');inflight={progress:structuredClone(progress),snapshot:await snapshot(f,'target'),nextChunkIndex:index+1,nextVerifyStep:0};}
 }
 let nextVerifyStep=0;for(;nextVerifyStep<500&&progress.state==='running';nextVerifyStep++){
  progress=await withCurrentRecoveryWorkspace(f,'target',async w=>advanceVerify(w,await recoveryContext(w,'verify',{manifest:original.manifest},f.captureId,{anchor:f.anchor,operationId:'verify_'+nextVerifyStep}),original.manifest));await evictDurableObject(f.target);
 }
 expect(progress.state).toBe('complete');expect(validateRecoveryReceipt(progress.receipt)).toBe(true);const completed={progress,snapshot:await snapshot(f,'target'),nextChunkIndex:original.chunks.length,nextVerifyStep};
 expect(completed.snapshot.tables.creation_admissions).toEqual([]);expect(completed.snapshot.tables.maintenance_state[0].state).toBe('restored');expect(completed.snapshot.tables.schema_migrations.length).toBe(17);
 expect(await digestBytes(canonicalBytes(original.manifest))).toBe(await digestBytes(canonicalBytes(capture.manifest)));
 await emit('genuine-schema17-restore-lifecycle-bundle.json',{provenance,fixture,capture,inflight,completed});
 console.log('SCHEMA17_CAPTURE_READY',JSON.stringify({schema:17,tableCounts:original.manifest.database.table_counts,chunks:chunks.length,artifacts:artifacts.length,pendingAdmission:admission.admission_id,partialImportNextChunk:boundary,completeRestoreState:progress.state,manifestSha256:await digestBytes(canonicalBytes(original.manifest))}));
},180000);
