import {it,expect} from 'vitest';
import {env} from 'cloudflare:workers';
import {runInDurableObject,evictDurableObject} from 'cloudflare:test';
import frozen from '../fixtures/genuine-schema17-restore-lifecycle-bundle.json';
import captured from '../fixtures/genuine-schema17-snapshot-bundle.json';
import {migrate} from '../../src/storage/migrations';
import {TABLE_REGISTRY} from '../../src/recovery/table-registry';
import {withCurrentRecoveryWorkspace,restoreCurrentFixture,targetArtifactBucket,type CurrentRestoreFixture,type captureCurrentFixture} from './current-restore-fixture';
import {artifactBucket} from '../helpers/artifacts';
import {recordProbe} from '../../src/recovery/probes';
import {resumeWorkspace,retireWorkspace,resolveDelivery} from '../../src/recovery/controls';
import {writeRestoreChunk,advanceVerify} from '../../src/recovery/restore';
import {recoveryContext,fixtureIntegrity} from '../helpers/recovery-fixture';
import {signRecord,verifyRecord,validateManifestShape} from '../../src/recovery/manifest';
import {canonicalBytes,digestBytes,decodeCurrentChunk} from '../../src/recovery/encoding';
import {validateRecoveryReceipt} from '../../src/recovery/generated/recovery-validators.js';
import type {RecoveryWorkspace,CurrentRecoveryManifest,CurrentLedger,RetirementReceipt,CutoverRecord,RecoveryJobProgress} from '../../src/recovery/protocol';
const manifest=frozen.capture.manifest as unknown as CurrentRecoveryManifest;
function fixture(){return {...structuredClone(frozen.fixture),source:env.WORKSPACE.getByName(frozen.fixture.sourceName),target:env.WORKSPACE.getByName(frozen.fixture.targetName)} as unknown as CurrentRestoreFixture;}
async function install(lane:'captured'|'inflight'|'completed'){
 const f=fixture(),snapshot=lane==='captured'?captured.snapshot:frozen[lane].snapshot,side=lane==='captured'?'source':'target';
 await runInDurableObject(f[side],async(_instance,{storage})=>{
  await storage.deleteAll();migrate(storage);
  storage.transactionSync(()=>{
   storage.sql.exec('PRAGMA defer_foreign_keys=ON');storage.sql.exec('DELETE FROM schema_migrations');
   for(const table of TABLE_REGISTRY)for(const row of snapshot.tables[table.name] as Record<string,string|number|null>[]){const keys=Object.keys(row);storage.sql.exec('INSERT INTO "'+table.name+'" ('+keys.map(k=>'"'+k+'"').join(',')+') VALUES ('+keys.map(()=>'?').join(',')+')',...keys.map(k=>row[k]));}
   storage.sql.exec('DELETE FROM sqlite_sequence');for(const row of snapshot.sequence)storage.sql.exec('INSERT INTO sqlite_sequence(name,seq) VALUES (?,?)',row.name,row.seq);
  });
 });
 for(const object of snapshot.objects)await env.RECOVERY_BUCKET.put(object.key,new Uint8Array(object.bytes));
 for(const object of snapshot.sourceArtifactObjects)await artifactBucket().put(object.key,new Uint8Array(object.bytes));
 for(const object of snapshot.targetArtifactObjects)await targetArtifactBucket().put(object.key,new Uint8Array(object.bytes));
 await evictDurableObject(f[side]);
 const work=<T>(body:(w:RecoveryWorkspace)=>Promise<T>|T)=>withCurrentRecoveryWorkspace(f,side,w=>{w.release=structuredClone(snapshot.release);return body(w);});
 return {f,work};
}
it('validates frozen original17 manifest signature, schema17 chunk bytes, aggregate digest, artifact bytes and rich pending authority evidence',async()=>{
 validateManifestShape(manifest);await verifyRecord(manifest,fixtureIntegrity);await verifyRecord(frozen.fixture.ledger as unknown as CurrentLedger,fixtureIntegrity);expect(validateRecoveryReceipt(frozen.capture.progress.receipt)).toBe(true);expect(validateRecoveryReceipt(frozen.completed.progress.receipt)).toBe(true);
 const stream=new (crypto as Crypto&{DigestStream:typeof DigestStream}).DigestStream('SHA-256'),writer=stream.getWriter();
 for(const c of frozen.capture.chunks){const bytes=new Uint8Array(c.bytes);expect(await digestBytes(bytes)).toBe(c.metadata.sha256);expect(bytes.byteLength).toBe(c.metadata.byte_size);expect(decodeCurrentChunk(bytes).schema_version).toBe(17);await writer.write(bytes);}await writer.close();expect(Array.from(new Uint8Array(await stream.digest),b=>b.toString(16).padStart(2,'0')).join('')).toBe(manifest.database.sha256);
 for(const a of frozen.capture.artifacts){const bytes=new Uint8Array(a.bytes);expect(await digestBytes(bytes)).toBe(a.entry.sha256);expect(bytes.byteLength).toBe(a.entry.byte_size);}
 expect(captured.snapshot.tables.creation_admissions).toHaveLength(1);expect(captured.snapshot.tables.tasks.length).toBeGreaterThan(0);expect(captured.snapshot.tables.messages.length).toBeGreaterThan(0);expect(captured.snapshot.tables.task_results.length).toBeGreaterThan(0);expect(frozen.capture.artifacts.length).toBeGreaterThan(0);
});
it('restores the untouched frozen17 capture into a fresh17 target and invalidates reservations without rewriting retained manifest',async()=>{
 const f=fixture(),before=await digestBytes(canonicalBytes(manifest));
 for(const a of frozen.capture.artifacts)await env.RECOVERY_BUCKET.put(a.entry.recovery_object_key,new Uint8Array(a.bytes));
 const capture={...frozen.capture,chunks:frozen.capture.chunks.map(c=>({...c,bytes:new Uint8Array(c.bytes).buffer}))} as unknown as Awaited<ReturnType<typeof captureCurrentFixture>>;
 const result=await restoreCurrentFixture(f,capture,{evict:true});expect(result.state).toBe('complete');
 await withCurrentRecoveryWorkspace(f,'target',w=>{expect(w.storage.sql.exec('SELECT MAX(version) AS v FROM schema_migrations').one().v).toBe(17);expect(w.storage.sql.exec('SELECT * FROM creation_admissions').toArray()).toEqual([]);const job=w.storage.sql.exec<{details_json:string}>("SELECT details_json FROM recovery_jobs WHERE operation='restore'").one();expect(JSON.parse(job.details_json).manifest).toEqual(manifest);});expect(await digestBytes(canonicalBytes(manifest))).toBe(before);
},90000);
it('restarts genuine17 partial import, retains exact build fence, and completes its original boundary',async()=>{
 const {f,work}=await install('inflight');
 for(const field of ['revision','worker_version'] as const)await work(async w=>{const before=w.storage.sql.exec('SELECT * FROM recovery_jobs').toArray();w.release={...w.release,[field]:'different_declared_build'};await expect(advanceVerify(w,await recoveryContext(w,'verify',{manifest},f.captureId,{anchor:f.anchor,operationId:'changed_'+field}),manifest)).rejects.toThrow('RECOVERY_SOURCE_IDENTITY_MISMATCH');expect(w.storage.sql.exec('SELECT * FROM recovery_jobs').toArray()).toEqual(before);});
 let progress=frozen.inflight.progress as RecoveryJobProgress;
 for(const c of frozen.capture.chunks.slice(frozen.inflight.nextChunkIndex)){const metadata={index:c.metadata.index,sha256:c.metadata.sha256,byte_size:c.metadata.byte_size};progress=await work(async w=>writeRestoreChunk(w,await recoveryContext(w,'write-chunk',metadata,f.captureId,{anchor:f.anchor,operationId:'continued_write_'+metadata.index}),metadata,new Uint8Array(c.bytes)));await evictDurableObject(f.target);}
 for(let step=0;step<500&&progress.state==='running';step++){progress=await work(async w=>advanceVerify(w,await recoveryContext(w,'verify',{manifest},f.captureId,{anchor:f.anchor,operationId:'continued_verify_'+step}),manifest));await evictDurableObject(f.target);}
 expect(progress.state).toBe('complete');await work(w=>{expect(w.storage.sql.exec('SELECT MAX(version) AS v FROM schema_migrations').one().v).toBe(17);expect(w.storage.sql.exec('SELECT state FROM maintenance_state').one().state).toBe('restored');expect(w.storage.sql.exec('SELECT * FROM creation_admissions').toArray()).toEqual([]);});
},90000);
it('restarts genuine17 captured source, probes17, retains reservations and exactly replays permanent retirement',async()=>{
 const {f,work}=await install('captured');const ledger=await signRecord<CurrentLedger>({workspace_id:'ws_example',environment_id:'current_source',authority_epoch:1,config:f.sourceInput.config,verification_bundle:f.sourceInput.bundle,installation_digest:f.sourceInput.installationDigest,retired_authorities:[],auth:{key_id:fixtureIntegrity.keyId,algorithm:'HMAC-SHA256',tag:'0'.repeat(64)}},fixtureIntegrity);f.resolver.anchor={authorityEpoch:1,sha256:await digestBytes(canonicalBytes(ledger))};
 const probe=await work(async w=>recordProbe(w,await recoveryContext(w,'probe',{},null,{anchor:f.resolver.anchor,operationId:'frozen17_source_probe'})));expect(probe.schema_version).toBe(17);
 await work(w=>expect(w.storage.sql.exec('SELECT * FROM creation_admissions').toArray()).toHaveLength(1));
 const retire=()=>work(async w=>retireWorkspace(w,await recoveryContext(w,'retire',{},f.captureId,{anchor:f.resolver.anchor,operationId:'frozen17_retire'})));const receipt=await retire();await evictDurableObject(f.source);expect(await retire()).toEqual(receipt);await verifyRecord(receipt,fixtureIntegrity);
 await work(w=>{expect(w.storage.sql.exec('SELECT state FROM maintenance_state').one().state).toBe('retired');expect(w.storage.sql.exec('SELECT MAX(version) AS v FROM schema_migrations').one().v).toBe(17);});
},90000);
it('restarts genuine17 completed target, confirms no unresolved effects, probes17 and exactly replays authorized synthetic resume',async()=>{
 const {f,work}=await install('completed');const ids=await work(w=>w.storage.sql.exec<{id:string}>("SELECT id FROM outbox WHERE status IN ('pending','in_flight')").toArray().map(r=>r.id));
 for(const id of ids){const body={delivery_id:id,disposition:'failed_without_redrive' as const,evidence_sha256:'a'.repeat(64)};await work(async w=>resolveDelivery(w,await recoveryContext(w,'resolve-delivery',body,f.captureId,{anchor:f.anchor,operationId:'resolve_'+id}),body));}
 const probe=await work(async w=>recordProbe(w,await recoveryContext(w,'probe',{},null,{anchor:f.anchor,operationId:'frozen17_target_probe'})));expect(probe.schema_version).toBe(17);
 // Synthetic external records only: no real retirement/cutover/deployment is claimed.
 const retirement=await signRecord<RetirementReceipt>({id:'retired_lifecycle17',capture_id:f.captureId,workspace_id:'ws_example',environment_id:'current_source',authority_epoch:1,barrier_id:manifest.checkpoint.barrier_id,retired_at:new Date().toISOString(),auth:{key_id:fixtureIntegrity.keyId,algorithm:'HMAC-SHA256',tag:'0'.repeat(64)}},fixtureIntegrity);
 const cutover=await signRecord<CutoverRecord>({id:'cutover_lifecycle17',capture_id:f.captureId,workspace_id:'ws_example',source_environment_id:'current_source',source_authority_epoch:1,target_environment_id:'current_target',target_authority_epoch:2,source_retirement_receipt_id:retirement.id,target_catalog_mapping:{workspace_id:'ws_example',object_name:f.targetName},cutover_at:new Date().toISOString(),auth:{key_id:fixtureIntegrity.keyId,algorithm:'HMAC-SHA256',tag:'0'.repeat(64)}},fixtureIntegrity);
 const body={receipt_id:frozen.completed.progress.receipt!.id,ledger:f.ledger,source_retirement_receipt:retirement,cutover_record:cutover};const resume=()=>work(async w=>resumeWorkspace(w,await recoveryContext(w,'resume',body,f.captureId,{anchor:f.anchor,operationId:'frozen17_target_resume'}),body));const result=await resume();await evictDurableObject(f.target);expect(await resume()).toEqual(result);
 await work(w=>{expect(w.storage.sql.exec('SELECT MAX(version) AS v FROM schema_migrations').one().v).toBe(17);expect(w.storage.sql.exec('SELECT state FROM maintenance_state').one().state).toBe('open');expect(w.storage.sql.exec('SELECT * FROM creation_admissions').toArray()).toEqual([]);});
},90000);
