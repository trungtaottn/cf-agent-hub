import {cloudflareTest} from '@cloudflare/vitest-plugin';
import {defineConfig} from 'vitest/config';
import {writeFile,mkdir} from 'node:fs/promises';
import {outboundProvider} from './test/helpers/outbound-oidc-provider';
const provider=await outboundProvider();
const destination='/workspace/shared/agenthub-b1-fixtures';
export default defineConfig({plugins:[cloudflareTest({main:'./test/helpers/historical-worker.ts',additionalExports:{HistoricalStorageDO:'DurableObject'},wrangler:{configPath:'./wrangler.jsonc',environment:'test'},miniflare:{serviceBindings:{RECOVERY_ANCHOR:async()=>new Response(null,{status:503}),SCHEMA17_FIXTURE_SINK:async(request:Request)=>{
 const name=new URL(request.url).pathname.slice(1);if(!['genuine-schema17-bundle.json','genuine-schema17-snapshot-bundle.json','genuine-schema17-restore-lifecycle-bundle.json'].includes(name))return new Response(null,{status:400});
 const body=await request.text();JSON.parse(body);await mkdir(destination,{recursive:true});await writeFile(destination+'/'+name,body+'\n');return new Response(null,{status:204});
}},r2Buckets:['TEST_RESTORE_ARTIFACT_BUCKET'],durableObjects:{HISTORICAL_WORKSPACE:{className:'HistoricalStorageDO',useSQLite:true}},bindings:provider.bindings,outboundService:async request=>{
const response=await provider.handler(new Request(request.url,{method:request.method,headers:Object.fromEntries(request.headers),body:request.method==='GET'||request.method==='HEAD'?undefined:await request.arrayBuffer(),redirect:'manual'}));return new Response(await response.arrayBuffer(),{status:response.status,headers:response.headers});
}}})],test:{include:['test/recovery/schema17-producer.test.ts'],fileParallelism:false}});
